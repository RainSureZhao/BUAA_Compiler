package midend.MidCode;

public interface MidCode {
}
