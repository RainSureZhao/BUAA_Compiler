package backend;

public interface ValueMeta {
}
