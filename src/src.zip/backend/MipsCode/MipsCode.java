/**
 * Created by 曾宪域 on 2023/12/13
 */
package backend.MipsCode;

public interface MipsCode {
}
